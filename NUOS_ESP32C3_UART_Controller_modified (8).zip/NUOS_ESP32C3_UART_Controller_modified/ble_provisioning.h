#pragma once
#include <Arduino.h>

void nuosBleProvisioningBegin();
void nuosBleProvisioningStart();
void nuosBleProvisioningStop();
void nuosBleProvisioningLoop();
bool nuosBleProvisioningConnected();
bool nuosBleProvisioningActive();
